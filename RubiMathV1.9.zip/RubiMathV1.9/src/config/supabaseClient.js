// This file is deprecated. Import from supabase.js instead
import supabase from './supabase';
export default supabase;
